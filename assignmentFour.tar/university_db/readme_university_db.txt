This database schema is used in exercise 3.11 and 3.12.
